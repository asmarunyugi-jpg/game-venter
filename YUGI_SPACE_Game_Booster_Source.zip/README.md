# YUGI SPACE — Game Booster (Android)

Native Android starter project using Kotlin. Target SDK 36 (Android 16), min SDK 26.

## Included
- Futuristic dark UI.
- FPS counter for **YUGI SPACE's own UI only** using Choreographer. It is not a universal FPS reader for other games.
- Game launcher that lists installed user apps and launches them.
- Resolution presets via Android shell `wm size`, plus reset (`wm size reset && wm density reset`).
- Shizuku API integration to request authorized shell access.
- Battery settings shortcut and overlay permission shortcut.

## Important limitations
- Wireless debugging alone does not grant an ordinary app shell access. Install and start Shizuku, pair it using Wireless debugging, and grant YUGI SPACE permission.
- `wm size` changes Android's logical display size; it does not change the physical panel resolution or guarantee higher FPS. Some games may ignore it or render incorrectly.
- The FPS counter measures this app's UI only. Reading another game's FPS needs device/game-specific support and cannot be guaranteed by a generic third-party app.
- The app does not forcibly overclock CPU/GPU, kill background tasks, or promise a performance increase.
- `QUERY_ALL_PACKAGES` is broad visibility. For distribution on Google Play, package visibility policy and permissions must be reviewed. Sideload/testing builds are easier for this prototype.
- Test on your own device. Always use Reset if screen scaling becomes inconvenient.

## Build APK with Android Studio
1. Install Android Studio on a computer and install Android SDK Platform 36.
2. Open this folder as a project.
3. Let Gradle sync. Use JDK 17 or the JDK bundled with Android Studio.
4. If sync fails, check internet access and that Maven Central/Google repositories are available.
5. Select **Build > Build APK(s)**.
6. Debug APK path: `app/build/outputs/apk/debug/app-debug.apk`.
7. Copy the APK to your Android phone, allow installation from that source, and install.

## Use resolution controls
1. Install Shizuku from its official source.
2. On Android 16, enable Developer options by tapping Build number seven times (Settings > About phone; exact menu differs by brand).
3. Enable Wireless debugging and pair/start Shizuku using its on-screen instructions.
4. Open YUGI SPACE and tap a resolution preset. Approve the Shizuku permission prompt.
5. Test the screen. If the display is awkward, use **Pulihkan resolusi bawaan**.

## Project structure
- `app/src/main/AndroidManifest.xml`
- `app/src/main/java/id/yugi/space/MainActivity.kt`
- `app/build.gradle.kts`

This is a starter implementation, not a claim that every Android device behaves identically. Verify build and runtime behavior on the target phone.
