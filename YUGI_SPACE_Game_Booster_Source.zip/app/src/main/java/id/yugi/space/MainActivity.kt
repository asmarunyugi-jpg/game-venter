package id.yugi.space

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Choreographer
import android.widget.*
import dev.rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 10, 25)
    private val panel = Color.rgb(17, 24, 48)
    private val cyan = Color.rgb(60, 220, 255)
    private val purple = Color.rgb(155, 105, 255)
    private lateinit var root: LinearLayout
    private lateinit var fpsText: TextView
    private lateinit var statusText: TextView
    private lateinit var resolutionText: TextView
    private lateinit var gameList: LinearLayout
    private var frameCount = 0
    private var lastFrameNs = 0L
    private var fps = 0
    private val handler = Handler(Looper.getMainLooper())
    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            frameCount++
            if (lastFrameNs == 0L) lastFrameNs = frameTimeNanos
            val elapsed = frameTimeNanos - lastFrameNs
            if (elapsed >= 1_000_000_000L) {
                fps = (frameCount * 1_000_000_000.0 / elapsed).roundToInt()
                fpsText.text = "$fps FPS"
                frameCount = 0
                lastFrameNs = frameTimeNanos
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
        Choreographer.getInstance().postFrameCallback(frameCallback)
        refreshResolutionStatus()
        refreshGames()
    }

    override fun onDestroy() {
        Choreographer.getInstance().removeFrameCallback(frameCallback)
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        val brand = TextView(this).apply {
            text = "✦ YUGI SPACE"
            textSize = 28f
            setTextColor(cyan)
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(brand)
        root.addView(text("GAME BOOSTER  •  ANDROID 16", 12, Color.LTGRAY).apply {
            setPadding(0, dp(4), 0, dp(18))
        })

        val fpsCard = card()
        fpsCard.addView(text("FPS MONITOR", 13, Color.LTGRAY))
        fpsText = text("-- FPS", 34, cyan).apply { typeface = Typeface.DEFAULT_BOLD }
        fpsCard.addView(fpsText)
        fpsCard.addView(text("Mengukur frame antarmuka YUGI SPACE, bukan FPS game lain.", 12, Color.LTGRAY))
        root.addView(fpsCard)

        val resCard = card()
        resCard.addView(text("SCREEN TUNER", 16, Color.WHITE).apply { typeface = Typeface.DEFAULT_BOLD })
        resolutionText = text("Membaca ukuran layar…", 12, Color.LTGRAY)
        resCard.addView(resolutionText)
        val choices = listOf(
            "Rendah • 720p" to 720,
            "Seimbang • 900p" to 900,
            "Tinggi • 1080p" to 1080,
            "Maksimum • native/reset" to 0
        )
        choices.forEach { (label, height) ->
            val b = button(label)
            b.setOnClickListener {
                if (height == 0) applyShell("wm size reset && wm density reset", "Reset resolusi dan density ke bawaan")
                else chooseResolution(height)
            }
            resCard.addView(b)
        }
        resCard.addView(button("Pulihkan resolusi bawaan").apply {
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Pulihkan layar?")
                    .setMessage("Mengembalikan ukuran dan density layar ke nilai bawaan Android.")
                    .setNegativeButton("Batal", null)
                    .setPositiveButton("Pulihkan") { _, _ ->
                        applyShell("wm size reset && wm density reset", "Pemulihan layar")
                    }.show()
            }
        })
        root.addView(resCard)

        val toolsCard = card()
        toolsCard.addView(text("PERFORMANCE TOOLS", 16, Color.WHITE).apply { typeface = Typeface.DEFAULT_BOLD })
        toolsCard.addView(text("Tidak ada tombol 'RAM cleaner' palsu. Android mengelola RAM sendiri.", 12, Color.LTGRAY))
        toolsCard.addView(button("Buka pengaturan baterai").apply {
            setOnClickListener {
                runCatching { startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)) }
                    .onFailure { toast("Menu baterai tidak tersedia pada perangkat ini.") }
            }
        })
        toolsCard.addView(button("Izin tampil di atas aplikasi").apply {
            setOnClickListener {
                val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                runCatching { startActivity(intent) }.onFailure { toast("Pengaturan overlay tidak tersedia.") }
            }
        })
        toolsCard.addView(button("Periksa status Shizuku").apply {
            setOnClickListener { checkShizuku() }
        })
        root.addView(toolsCard)

        val gamesCard = card()
        gamesCard.addView(text("GAME LAUNCHER", 16, Color.WHITE).apply { typeface = Typeface.DEFAULT_BOLD })
        gamesCard.addView(text("Aplikasi yang bisa dibuka dari perangkat ini.", 12, Color.LTGRAY))
        gameList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        gamesCard.addView(gameList)
        gamesCard.addView(button("Muat ulang daftar game").apply { setOnClickListener { refreshGames() } })
        root.addView(gamesCard)

        statusText = text("Status: siap", 12, cyan)
        statusText.setPadding(0, dp(12), 0, dp(4))
        root.addView(statusText)
        root.addView(text("Catatan: perubahan resolusi sistem memerlukan Shizuku aktif dan izin shell. Uji bertahap; resolusi terlalu rendah dapat mengganggu tampilan.", 11, Color.LTGRAY))
    }

    private fun chooseResolution(targetHeight: Int) {
        val metrics = resources.displayMetrics
        val currentW = metrics.widthPixels
        val currentH = metrics.heightPixels
        val aspect = currentW.toFloat() / currentH.coerceAtLeast(1)
        val landscape = currentW > currentH
        val w = (targetHeight * aspect).roundToInt().coerceAtLeast(320)
        val h = targetHeight.coerceAtLeast(320)
        val width = if (landscape) w else h
        val height = if (landscape) h else w
        AlertDialog.Builder(this)
            .setTitle("Terapkan preset ${targetHeight}p?")
            .setMessage("Perkiraan ukuran virtual: ${width}x${height}. Ini mengubah ukuran tampilan sistem, bukan kemampuan panel fisik. Jika tampilan bermasalah, gunakan Pulihkan resolusi bawaan.")
            .setNegativeButton("Batal", null)
            .setPositiveButton("Terapkan") { _, _ ->
                applyShell("wm size ${width}x${height}", "Terapkan resolusi")
            }.show()
    }

    private fun applyShell(command: String, actionLabel: String) {
        if (!runCatching { Shizuku.pingBinder() }.getOrDefault(false)) {
            statusText.text = "Shizuku belum aktif. Jalankan Shizuku dan izinkan YUGI SPACE, lalu coba lagi."
            AlertDialog.Builder(this)
                .setTitle("Shizuku diperlukan")
                .setMessage("Wireless debugging harus dipasangkan di aplikasi Shizuku terlebih dahulu. Setelah Shizuku berjalan, berikan izin kepada YUGI SPACE. Aplikasi tidak dapat memperoleh akses ADB hanya dengan mengaktifkan Wireless debugging.")
                .setPositiveButton("Mengerti", null)
                .show()
            return
        }
        try {
            if (Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                Shizuku.requestPermission(1001)
                statusText.text = "Permintaan izin Shizuku dikirim. Izinkan, lalu tekan tombol lagi."
                return
            }
            Thread {
                var output = ""
                var exitCode = -1
                try {
                    val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
                    output = BufferedReader(InputStreamReader(process.inputStream)).use { it.readText() }
                    val err = BufferedReader(InputStreamReader(process.errorStream)).use { it.readText() }
                    if (err.isNotBlank()) output += "\n$err"
                    exitCode = process.waitFor()
                } catch (e: Exception) {
                    output = e.message ?: "Perintah gagal dijalankan"
                }
                val finalOutput = output
                val finalExit = exitCode
                runOnUiThread {
                    statusText.text = if (finalExit == 0) "$actionLabel: berhasil" else "$actionLabel: gagal"
                    refreshResolutionStatus()
                    AlertDialog.Builder(this)
                        .setTitle(if (finalExit == 0) "Perintah selesai" else "Perintah gagal")
                        .setMessage((if (finalOutput.isBlank()) "Perintah selesai tanpa keluaran." else finalOutput) +
                            "\n\nJika gagal, periksa izin Shizuku atau pulihkan resolusi bawaan.")
                        .setPositiveButton("OK", null).show()
                }
            }.start()
        } catch (e: Exception) {
            statusText.text = "Tidak dapat menjalankan perintah shell."
            toast("Gagal: ${e.message ?: "kesalahan tidak diketahui"}")
        }
    }

    private fun checkShizuku() {
        val active = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
        val permission = active && runCatching {
            Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED
        }.getOrDefault(false)
        val message = when {
            !active -> "Shizuku belum berjalan. Pasangkan Shizuku menggunakan Wireless debugging, lalu mulai layanan."
            !permission -> "Shizuku aktif, tetapi YUGI SPACE belum diberi izin. Tekan tombol fitur resolusi untuk meminta izin."
            else -> "Shizuku aktif dan izin aplikasi sudah diberikan."
        }
        statusText.text = message
        AlertDialog.Builder(this).setTitle("Status Shizuku").setMessage(message).setPositiveButton("OK", null).show()
    }

    private fun refreshResolutionStatus() {
        val dm = resources.displayMetrics
        resolutionText.text = "Ukuran logis saat ini: ${dm.widthPixels} × ${dm.heightPixels} • density ${dm.densityDpi} dpi\nPreset mengubah wm size; panel fisik dan dukungan game tetap menentukan hasil."
    }

    @Suppress("DEPRECATION")
    private fun refreshGames() {
        gameList.removeAllViews()
        val pm = packageManager
        val apps = pm.getInstalledApplications(0)
            .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 && it.packageName != packageName }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase(Locale.getDefault()) }
        if (apps.isEmpty()) {
            gameList.addView(text("Belum ada aplikasi pengguna yang terdeteksi.", 13, Color.LTGRAY))
            return
        }
        val games = apps.filter {
            val label = pm.getApplicationLabel(it).toString().lowercase(Locale.getDefault())
            listOf("game", "pubg", "mobile legends", "free fire", "minecraft", "roblox", "genshin", "cod", "call of duty", "asphalt", "wild rift", "honor of kings").any(label::contains)
        }
        val displayApps = if (games.isNotEmpty()) games else apps.take(30)
        displayApps.take(60).forEach { app ->
            val label = pm.getApplicationLabel(app).toString()
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(5), 0, dp(5))
            }
            val name = TextView(this).apply {
                text = label
                textSize = 14f
                setTextColor(Color.WHITE)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            val launch = button("BUKA").apply {
                textSize = 11f
                setOnClickListener {
                    val intent = pm.getLaunchIntentForPackage(app.packageName)
                    if (intent != null) runCatching { startActivity(intent) }
                        .onFailure { toast("Game tidak bisa dibuka.") }
                    else toast("Aplikasi ini tidak menyediakan aktivitas peluncur.")
                }
            }
            row.addView(name)
            row.addView(launch)
            gameList.addView(row)
        }
        if (displayApps.isEmpty()) gameList.addView(text("Tidak ada game yang terdeteksi. Daftar aplikasi dapat berbeda menurut perangkat.", 12, Color.LTGRAY))
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(14), dp(14), dp(14))
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(panel)
            cornerRadius = dp(18).toFloat()
            setStroke(dp(1), Color.rgb(43, 65, 100))
        }
        val params = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        params.bottomMargin = dp(14)
        layoutParams = params
    }

    private fun text(value: String, size: Int, color: Int) = TextView(this).apply {
        text = value
        textSize = size.toFloat()
        setTextColor(color)
        setPadding(0, dp(4), 0, dp(6))
    }

    private fun button(label: String): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 14f
        setTextColor(Color.WHITE)
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.rgb(38, 65, 115))
            cornerRadius = dp(12).toFloat()
        }
        val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        p.topMargin = dp(5)
        p.bottomMargin = dp(3)
        layoutParams = p
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()
}
