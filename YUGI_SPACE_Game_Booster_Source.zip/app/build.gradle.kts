plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "id.yugi.space"
    compileSdk = 36

    defaultConfig {
        applicationId = "id.yugi.space"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }
}

dependencies {
    implementation("dev.rikka.shizuku:api:13.1.5")
}
